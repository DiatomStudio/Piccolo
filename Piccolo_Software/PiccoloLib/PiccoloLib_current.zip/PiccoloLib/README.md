/*
  PiccoloLib v0.2 - Library for controlling Piccolo the tiny CNC-bot.
  Piccolo.cc
  Created by Diatom Studio, October 10, 2013.
  Released into the public domain.

  --Changes:--

  ---0.2---

*/
